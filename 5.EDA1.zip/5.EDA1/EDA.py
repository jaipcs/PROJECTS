# eda_cardiotocographic.py

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# Load the dataset
df = pd.read_csv("Cardiotocographic.csv")

# Basic Information
print("First 5 rows of the dataset:")
print(df.head())

print("\nDataset Info:")
print(df.info())

print("\nStatistical Summary:")
print(df.describe())

# Check for missing values
print("\nMissing Values:")
print(df.isnull().sum())

# Convert data types if necessary (example: ensure all are numeric)
df = df.apply(pd.to_numeric, errors='coerce')

# Handling missing values (drop rows with NA)
df.dropna(inplace=True)

# Outlier detection using IQR
def detect_outliers_iqr(data, feature):
    Q1 = data[feature].quantile(0.25)
    Q3 = data[feature].quantile(0.75)
    IQR = Q3 - Q1
    lower = Q1 - 1.5 * IQR
    upper = Q3 + 1.5 * IQR
    return data[(data[feature] < lower) | (data[feature] > upper)]

print("\nOutliers Detected:")
for col in df.columns:
    outliers = detect_outliers_iqr(df, col)
    print(f"{col}: {len(outliers)}")

# Visualization: Histograms
df.hist(bins=15, figsize=(15, 10))
plt.tight_layout()
plt.suptitle("Histograms of All Features", y=1.02)
plt.show()

# Visualization: Boxplots
plt.figure(figsize=(15, 8))
sns.boxplot(data=df)
plt.title("Boxplot of All Features")
plt.xticks(rotation=90)
plt.show()

# Correlation Matrix
plt.figure(figsize=(12, 10))
sns.heatmap(df.corr(), annot=True, fmt=".2f", cmap="coolwarm")
plt.title("Correlation Heatmap")
plt.show()

# Pairplot
sns.pairplot(df.sample(n=100))  # sample to reduce computation
plt.suptitle("Pairplot Sample", y=1.02)
plt.show()

# Violin plots
for col in df.columns:
    plt.figure(figsize=(8, 4))
    sns.violinplot(x=df[col])
    plt.title(f"Violin plot of {col}")
    plt.show()

# Summary
print("\nEDA Completed. Key points should be added manually in report based on visual findings.")
