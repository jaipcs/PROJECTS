# multiple_linear_regression.py

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression, Ridge, Lasso
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline

# Load the dataset
df = pd.read_csv("ToyotaCorolla - MLR.csv")

# Display basic info and check for nulls
print(df.info())
print(df.describe())
print(df.isnull().sum())

# Exploratory Data Analysis
plt.figure(figsize=(10, 6))
sns.heatmap(df.corr(numeric_only=True), annot=True, cmap="coolwarm")
plt.title("Correlation Heatmap")
plt.show()

sns.pairplot(df[['Price', 'Age', 'KM', 'HP', 'Weight']])
plt.show()

# Features and target
X = df[['Age', 'KM', 'FuelType', 'HP', 'Automatic', 'CC', 'Doors', 'Weight', 'Quarterly_Tax']]
y = df['Price']

# Preprocessing: OneHotEncoding for FuelType, Standardization for numerical values
categorical_features = ['FuelType']
numeric_features = ['Age', 'KM', 'HP', 'Automatic', 'CC', 'Doors', 'Weight', 'Quarterly_Tax']

preprocessor = ColumnTransformer(
    transformers=[
        ('num', StandardScaler(), numeric_features),
        ('cat', OneHotEncoder(drop='first'), categorical_features)
    ])

# Splitting the dataset
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Model 1: Basic Linear Regression
pipeline_lr = Pipeline(steps=[('preprocessor', preprocessor),
                              ('regressor', LinearRegression())])
pipeline_lr.fit(X_train, y_train)

y_pred_lr = pipeline_lr.predict(X_test)
print("\nModel 1 - Linear Regression")
print("R^2 Score:", r2_score(y_test, y_pred_lr))
print("RMSE:", np.sqrt(mean_squared_error(y_test, y_pred_lr)))

# Model 2: Ridge Regression
pipeline_ridge = Pipeline(steps=[('preprocessor', preprocessor),
                                 ('regressor', Ridge(alpha=1.0))])
pipeline_ridge.fit(X_train, y_train)
y_pred_ridge = pipeline_ridge.predict(X_test)

print("\nModel 2 - Ridge Regression")
print("R^2 Score:", r2_score(y_test, y_pred_ridge))
print("RMSE:", np.sqrt(mean_squared_error(y_test, y_pred_ridge)))

# Model 3: Lasso Regression
pipeline_lasso = Pipeline(steps=[('preprocessor', preprocessor),
                                 ('regressor', Lasso(alpha=0.1))])
pipeline_lasso.fit(X_train, y_train)
y_pred_lasso = pipeline_lasso.predict(X_test)

print("\nModel 3 - Lasso Regression")
print("R^2 Score:", r2_score(y_test, y_pred_lasso))
print("RMSE:", np.sqrt(mean_squared_error(y_test, y_pred_lasso)))

# Optional: Coefficient interpretation (for Linear Regression)
model = pipeline_lr.named_steps['regressor']
features_after_encoding = pipeline_lr.named_steps['preprocessor'].get_feature_names_out()
coefficients = pd.Series(model.coef_, index=features_after_encoding)
print("\nModel Coefficients:")
print(coefficients.sort_values(ascending=False))

# Interview Question Answers
print("\nInterview Q1: Normalization vs Standardization")
print("Normalization scales data between 0 and 1. Standardization transforms it to have mean 0 and std 1. Helpful in regression to ensure features are comparable in scale.")

print("\nInterview Q2: Addressing Multicollinearity")
print("Techniques: Remove correlated variables, apply PCA, use regularization (Ridge/Lasso). Ridge is especially helpful for handling multicollinearity.")

