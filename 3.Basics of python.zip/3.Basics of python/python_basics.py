# Exercise 1: Prime Numbers
def is_prime(n):
    if n <= 1:
        return False
    for i in range(2, int(n**0.5) + 1):
        if n % i == 0:
            return False
    return True

# Example usage:
print("Is 17 a prime number?", is_prime(17))


# Exercise 2: Product of Random Numbers
import random

num1 = random.randint(1, 10)
num2 = random.randint(1, 10)
print(f"What is the product of {num1} and {num2}?")
user_answer = int(input("Enter your answer: "))

if user_answer == num1 * num2:
    print("Correct!")
else:
    print(f"Incorrect. The correct answer is {num1 * num2}.")


# Exercise 3: Squares of Even Numbers (100 to 200)
print("Squares of even numbers from 100 to 200:")
for i in range(100, 201):
    if i % 2 == 0:
        print(f"{i}^2 = {i**2}")


# Exercise 4: Word Counter
def word_counter(text):
    words = text.split()
    word_count = {}
    for word in words:
        word = word.strip(".,!?").capitalize()
        word_count[word] = word_count.get(word, 0) + 1
    return word_count

input_text = "This is a sample text. This text will be used to demonstrate the word counter."
print("Word counts:", word_counter(input_text))


# Exercise 5: Check for Palindrome
def is_palindrome(s):
    cleaned = ''.join(c.lower() for c in s if c.isalnum())
    return cleaned == cleaned[::-1]

# Example usage:
print("Is 'racecar' a palindrome?", is_palindrome("racecar"))
