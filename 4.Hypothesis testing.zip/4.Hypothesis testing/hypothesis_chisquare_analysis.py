# hypothesis_chisquare_analysis.py

import scipy.stats as stats
import numpy as np

# -------------------------------
# Part 1: Chi-Square Test
# -------------------------------

# Observed Frequency Table (Contingency Table)
observed = np.array([
    [50, 70],    
    [80, 100],  
    [60, 90],    
    [30, 50],   
    [20, 50]    
])

# Step 1: State the Hypotheses
# H0: No association between device type and satisfaction level
# H1: There is an association between device type and satisfaction level

# Step 2: Compute the Chi-Square Statistic
chi2, p, dof, expected = stats.chi2_contingency(observed)

# Step 3: Determine the Critical Value
alpha = 0.05
critical_value = stats.chi2.ppf(1 - alpha, df=dof)

# Step 4: Make a Decision
chi_square_result = "Reject H0" if chi2 > critical_value else "Fail to Reject H0"

# -------------------------------
# Part 2: Hypothesis Testing for Weekly Cost
# -------------------------------

# Step 1: Hypotheses
# H0: μ = theoretical cost = 1000 + 5*600 = Rs. 4000
# H1: μ > 4000

# Given values
sample_mean = 3050
theoretical_mean = 1000 + 5 * 600  # = 4000
sigma = 5 * 25  # = 125
n = 25

# Step 2: Calculate the Test Statistic (Z-test)
z = (sample_mean - theoretical_mean) / (sigma / np.sqrt(n))

# Step 3: Critical Value for one-tailed test at α = 0.05
z_critical = stats.norm.ppf(0.95)

# Step 4: Decision
hypothesis_result = "Reject H0" if z > z_critical else "Fail to Reject H0"

# -------------------------------
# Final Output
# -------------------------------

print("=== Chi-Square Test ===")
print(f"Chi-Square Statistic: {chi2:.4f}")
print(f"Degrees of Freedom: {dof}")
print(f"Critical Value at 0.05 significance: {critical_value:.4f}")
print(f"P-value: {p:.4f}")
print(f"Expected Frequencies:\n{expected}")
print(f"Decision: {chi_square_result}\n")

print("=== Hypothesis Testing ===")
print(f"Z-Statistic: {z:.4f}")
print(f"Critical Z-Value (α = 0.05): {z_critical:.4f}")
print(f"Decision: {hypothesis_result}")
