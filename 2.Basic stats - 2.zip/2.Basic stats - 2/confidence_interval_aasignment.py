
import numpy as np
import scipy.stats as stats

# Data  : Durability of 15 print-heads (in millions of characters)
durability_data = np.array([
    1.13, 1.55, 1.43, 0.92, 1.25, 1.36, 1.32, 0.85, 1.07,
    1.48, 1.20, 1.33, 1.18, 1.22, 1.29
])

# Sample statistics
sample_mean = np.mean(durability_data)
sample_std = np.std(durability_data, ddof=1)
n = len(durability_data)

# a. 99% Confidence Interval using sample standard deviation (t-distribution)
confidence_level = 0.99
alpha = 1 - confidence_level
t_critical = stats.t.ppf(1 - alpha/2, df=n-1)
margin_of_error_t = t_critical * (sample_std / np.sqrt(n))
ci_t = (sample_mean - margin_of_error_t, sample_mean + margin_of_error_t)

print("Using Sample Standard Deviation (t-distribution):")
print(f"Mean = {sample_mean:.4f}")
print(f"Standard Deviation = {sample_std:.4f}")
print(f"99% Confidence Interval: {ci_t[0]:.4f} to {ci_t[1]:.4f}")

# b. 99% Confidence Interval using known population standard deviation (z-distribution)
pop_std = 0.2
z_critical = stats.norm.ppf(1 - alpha/2)
margin_of_error_z = z_critical * (pop_std / np.sqrt(n))
ci_z = (sample_mean - margin_of_error_z, sample_mean + margin_of_error_z)

print("\nUsing Known Population Standard Deviation (z-distribution):")
print(f"Mean = {sample_mean:.4f}")
print(f"Population Standard Deviation = {pop_std}")
print(f"99% Confidence Interval: {ci_z[0]:.4f} to {ci_z[1]:.4f}")
