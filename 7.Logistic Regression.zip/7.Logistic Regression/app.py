#!/usr/bin/env python
# coding: utf-8

# In[1]:


# app.py - Streamlit UI to load trained model and make predictions
import streamlit as st
import numpy as np
import pickle

# Load trained model
@st.cache_resource
def load_model():
    return pickle.load(open("logreg_model.pkl", "rb"))

model = load_model()

st.title("🚢 Titanic Survival Prediction")

# User input form
sex = st.selectbox("Sex", ['male', 'female'])
pclass = st.selectbox("Passenger Class", [1, 2, 3])
age = st.slider("Age", 0, 100, 30)
sibsp = st.number_input("Siblings/Spouses Aboard", 0, 10, 0)
parch = st.number_input("Parents/Children Aboard", 0, 10, 0)
fare = st.number_input("Fare", 0.0, 600.0, 32.0)
embarked = st.selectbox("Embarked", ['S', 'C', 'Q'])

# Encode categorical values
sex_encoded = 1 if sex == 'male' else 0
embarked_encoded = {'S': 2, 'C': 0, 'Q': 1}[embarked]

# Feature array
features = np.array([[pclass, sex_encoded, age, sibsp, parch, fare, embarked_encoded]])

# Predict
if st.button("Predict"):
    prediction = model.predict(features)[0]
    if prediction == 1:
        st.success("🎉 The passenger survived!")
    else:
        st.error("😢 The passenger did not survive.")


# In[ ]:




